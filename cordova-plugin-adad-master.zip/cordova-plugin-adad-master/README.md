Cordova Dgad plugin
====================
# Overview #
Show Dgad Ads

[android] [cordova cli] [xdk] [cocoon] [phonegap build service]

Requires Dgad account http://dgad.ir

Created by: Milad Mohammadi

http://miladesign.ir

